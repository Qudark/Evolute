/* ============================================================
   config.js — НАСТРОЙКИ ПРОЕКТА
   ============================================================
   Чтобы игра реально синхронизировалась между разными
   телефонами (в том числе через Telegram), нужно бесплатное
   хранилище в интернете. Проще всего — Firebase Realtime
   Database (бесплатный тариф Spark, без карты).

   Как получить свои ключи (5 минут, бесплатно):
   1. https://console.firebase.google.com → «Add project»
   2. В новом проекте: Build → Realtime Database → Create
      Database → выбрать любой регион → Start in "test mode"
      (для личной игры с друзьями этого достаточно).
   3. Project settings (шестерёнка) → General → в блоке
      "Your apps" нажать иконку "</>" (Web) → зарегистрировать
      приложение → скопировать объект firebaseConfig.
   4. Вставить его сюда вместо пустого объекта ниже.

   Пока этот объект пустой — игра сама попробует работать через
   встроенное хранилище Claude (только для теста прямо в этом
   чате) или в локальном офлайн-режиме на одном устройстве.
   ============================================================ */

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyBFayIhEzjeNqusup3KA1sPIGc_9RRKeaw",
  authDomain: "evolute-79220.firebaseapp.com",
  databaseURL: "https://evolute-79220-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "evolute-79220",
  storageBucket: "evolute-79220.firebasestorage.app",
  messagingSenderId: "651890149404",
  appId: "1:651890149404:web:3cd179e75028aa309f37d9",
};

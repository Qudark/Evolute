/* ============================================================
   board/controls.js — разовая настройка интерактива стола:
   стрелки/свайп соперников, всплывающее меню, переключение
   вкладок из меню (через общий nav.js), кормовая база и
   разметка зоны сброса как drop-цели.
   ============================================================ */
import { setView } from '../nav.js';
import { getRoom } from './state.js';
import { getSession } from '../session.js';
import { renderGame } from './render.js';
import { foodAdjust } from './drop-handlers.js';
import { markDropzone } from './dropzone-utils.js';
import * as Opponents from './opponents-view.js';

function currentOpponents(){
  const room = getRoom();
  const session = getSession();
  return room ? room.players.filter(p => p.id !== session.playerId) : [];
}

export function setupControls(){
  document.getElementById('oppArrowLeft').addEventListener('click', () => {
    if (Opponents.arrowLeft()) renderGame();
  });
  document.getElementById('oppArrowRight').addEventListener('click', () => {
    if (Opponents.arrowRight(currentOpponents().length)) renderGame();
  });

  const strip = document.getElementById('opponentStrip');
  let touchStartX = 0;
  strip.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
  }, { passive: true });
  strip.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Opponents.swipe(diff, currentOpponents().length)) renderGame();
  }, { passive: true });

  document.getElementById('menuDots').addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('controlsPopup').classList.toggle('open');
  });
  document.addEventListener('click', () => {
    document.getElementById('controlsPopup').classList.remove('open');
  });

  document.querySelectorAll('.ctrl-btn[data-view]').forEach(btn => {
    btn.addEventListener('click', () => setView(btn.dataset.view));
  });

  // Единственное место, где навешиваются обработчики кормовой
  // базы — раньше main.js дублировал их, из-за чего клик
  // изменял счётчик сразу на 2.
  document.getElementById('foodMinus').addEventListener('click', () => foodAdjust(-1));
  document.getElementById('foodPlus').addEventListener('click', () => foodAdjust(1));

  // Стопка сброса — теперь настоящая drop-цель (раньше карту
  // некуда было физически перетащить, хотя обработчик уже был).
  const discardPile = document.getElementById('discardPile');
  if (discardPile) markDropzone(discardPile, { zoneType: 'discard' });
}
